/*
 * sct.h
 *
 *  Created on: 14 Oct 2020
 *      Author: User
 */

#ifndef SRC_SCT_H_
#define SRC_SCT_H_

void sct_led(uint32_t value);
void sct_init(void);
void sct_value( uint16_t value);

#endif /* SRC_SCT_H_ */
